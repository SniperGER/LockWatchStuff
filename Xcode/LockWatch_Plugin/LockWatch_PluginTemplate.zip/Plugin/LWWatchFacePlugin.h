//
//  LWWatchFacePlugin.h
//  LockWatch_Plugin
//
//  Created by Janik Schmidt on 01.12.15.
//
//

#import <UIKit/UIKit.h>
#import <WatchFaceBase/WatchFaceBase.h>

#error LWWatchFacePlugin is already defined.
@interface LWWatchFacePlugin : WatchFaceBase {
    int detailState;
}

@end
